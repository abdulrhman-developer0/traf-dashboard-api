export default [
    {
      title: 'Dashboard',
      to: { name: 'index' },
      icon: { icon: 'tabler-smart-home' },
      path: '/',
      permission: 'dashboard-dashboard-view'
    }
  ]
  