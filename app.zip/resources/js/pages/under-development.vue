<template>
  <div>
    <VCard title="Under development Page 🙌">
      <VCardText>This page is under development</VCardText>
    </VCard>
  </div>
</template>
