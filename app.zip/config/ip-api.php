<?php

return [
    'key' => env('IP_API_KEY', ''),
    'url' => env('IP_API_URL', 'http://ip-api.com/json/'),
    'lang' => env('IP_API_LANG', 'en'),
];
