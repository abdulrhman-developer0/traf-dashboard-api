<!-- Top Bar
============================================= -->
<div id="top-bar" class="transparent-topbar">
    <div class="container">

        <div class="row justify-content-between">
            <div class="col-12 col-md-auto">

                <!-- Top Links
                ============================================= -->
                <div class="top-links">
                    <ul class="top-links-container">
                        <li class="top-links-item"><a href="">IRO ERASMUS+</a></li>
                        <li class="top-links-item"><a href="">IELTS</a></li>
                        
                    </ul>
                </div><!-- .top-links end -->

            </div>

            <div class="col-12 col-md-auto">
                <div class="top-links">
                    <ul class="top-links-container">
                        <li class="top-links-item"><a href=""><i class="bi bi-telephone-fill"></i> +01 572 172 6782</a></li>
                        <li class="top-links-item"><a href="mailto:KNU@example.com"><i class="bi bi-envelope-fill"></i> KNU@example.com</a></li>
                        <li class="top-links-item"><a href="#"><img src="<?php echo e(asset('website-assets/images/flags/eng.png')); ?>" alt="Lang">English</a>
                            <ul class="top-links-sub-menu">
                                <li class="top-links-item"><a href="/en"><img src="<?php echo e(asset('website-assets/images/flags/eng.png')); ?>" alt="Lang">English</a></li>
                                <li class="top-links-item"><a href="/ar"><img src="<?php echo e(asset('website-assets/images/flags/ara.png')); ?>" alt="Lang">Arabic</a></li>
                                <li class="top-links-item"><a href="/ku"><img src="<?php echo e(asset('website-assets/images/flags/tha.png')); ?>" alt="Lang">Kurdish</a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!-- .top-links end -->

                <!-- Top Social
                ============================================= -->
                <!-- <ul id="top-social">
                    <li><a href="https://facebook.com/semicolonweb" class="h-bg-facebook" target="_blank"><span class="ts-icon"><i class="fa-brands fa-facebook-f"></i></span><span class="ts-text">Facebook</span></a></li>
                    <li><a href="https://twitter.com/__semicolon" class="h-bg-x-twitter" target="_blank"><span class="ts-icon"><i class="fa-brands fa-x-twitter"></i></span><span class="ts-text">Twitter</span></a></li>
                    <li><a href="https://youtube.com/semicolonweb" class="h-bg-youtube" target="_blank"><span class="ts-icon"><i class="fa-brands fa-youtube"></i></span><span class="ts-text">Youtube</span></a></li>
                    <li><a href="https://instagram.com/semicolonweb" class="h-bg-instagram" target="_blank"><span class="ts-icon"><i class="fa-brands fa-instagram"></i></span><span class="ts-text">Instagram</span></a></li>
                    <li><a href="tel:+10.11.85412542" class="h-bg-call"><span class="ts-icon"><i class="fa-solid fa-phone"></i></span><span class="ts-text">+10.11.85412542</span></a></li>
                    <li><a href="mailto:info@canvas.com" class="h-bg-email3"><span class="ts-icon"><i class="bi-envelope-fill"></i></span><span class="ts-text">info@canvas.com</span></a></li>
                </ul>#top-social end -->

            </div>
        </div>

    </div>
</div><!-- #top-bar end -->

<!-- Header
============================================= -->
<header id="header" class="">
    <div id="header-wrap">
        <div class="container">
            <div class="header-row">

                <!-- Logo
                ============================================= -->
                <div id="logo">
                    <a href="/">
                        <img class=" d-none logo-default" src="<?php echo e(asset('website-assets/images/footer-logo.png')); ?>" alt="Knowledge University">
                    </a>
                </div><!-- #logo end -->

                <div class="header-misc">

                    <!-- Top Search
                    ============================================= -->
                    <div id="top-search" class="header-misc-icon">
                        <a href="#" id="top-search-trigger"><i class="uil uil-search"></i><i class="bi-x-lg"></i></a>
                    </div><!-- #top-search end -->
                </div>

                <div class="primary-menu-trigger">
                    <button class="cnvs-hamburger" type="button" title="Open Mobile Menu">
                        <span class="cnvs-hamburger-box"><span class="cnvs-hamburger-inner"></span></span>
                    </button>
                </div>

                <!-- Primary Navigation
                ============================================= -->
                <nav class="primary-menu with-arrows">

                    <ul class="menu-container">
                        <li class="menu-item"><a class="menu-link" href="<?php echo e(LaravelLocalization::localizeUrl('/')); ?>"><div>Home</div></a></li>
                        <li class="menu-item"><a class="menu-link" href="<?php echo e(LaravelLocalization::localizeUrl('/articles')); ?>"><div>Articles</div></a></li>
                        <li class="menu-item"><a class="menu-link" href="<?php echo e(LaravelLocalization::localizeUrl('/contact')); ?>"><div>Contact</div></a></li>
                    </ul>

                </nav><!-- #primary-menu end -->

                <form class="top-search-form" action="search.html" method="get">
                    <input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter.." autocomplete="off">
                </form>

            </div>
        </div>
    </div>
    <div class="header-wrap-clone"></div>
</header><!-- #header end --><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/header.blade.php ENDPATH**/ ?>