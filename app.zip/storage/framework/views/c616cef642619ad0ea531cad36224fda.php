<div class="section mt-0" style="background-color: #E9F3FB; padding: 90px 0;">
    <div class="container">

        <div class="row col-mb-30">

            <div class="col-lg-3 col-md-4 col-6 text-center" style="border-right: 1px solid #1D1D1D2E;">
                <img src="<?php echo e(asset('website-assets/images/colleges.png')); ?>" alt="" width="80" height="80">
                <div class="clear"></div>
                <h5 style="font-size: 24px; color: #000; margin-top: 15px; font-weight:500;margin-bottom:15px">Colleges</h5>
                <div class="counter counter-small" style="font-family:'Lato', sans-serif; font-size: 48px; font-weight:700;color:#000;line-height: 0;padding-top: 15px;">
                    <span data-from="0" data-to="3" data-refresh-interval="1" data-speed="500"></span></div>

            </div>
            <div class="col-lg-3 col-md-4 col-6 text-center" style="border-right: 1px solid #1D1D1D2E;">
                <img src="<?php echo e(asset('website-assets/images/programs.png')); ?>" alt="" width="80" height="80">
                <div class="clear"></div>
                <h5 style="font-size: 24px; color: #000; margin-top: 15px; font-weight:500;margin-bottom:15px">Programs</h5>
                <div class="counter counter-small" style="font-family:'Lato', sans-serif; font-size: 48px; font-weight:700;color:#000;line-height: 0;padding-top: 15px;">
                    <span data-from="0" data-to="3" data-refresh-interval="1" data-speed="500"></span></div>

            </div>
            <div class="col-lg-3 col-md-4 col-6 text-center" style="border-right: 1px solid #1D1D1D2E;">
                <img src="<?php echo e(asset('website-assets/images/students.png')); ?>" alt="" width="80" height="80">
                <div class="clear"></div>
                <h5 style="font-size: 24px; color: #000; margin-top: 15px; font-weight:500;margin-bottom:15px">Students</h5>
                <div class="counter counter-small" style="font-family:'Lato', sans-serif; font-size: 48px; font-weight:700;color:#000;line-height: 0;padding-top: 15px;">
                    <span data-from="0" data-to="3" data-refresh-interval="1" data-speed="500"></span></div>

            </div>
            <div class="col-lg-3 col-md-4 col-6 text-center">
                <img src="<?php echo e(asset('website-assets/images/alumni.png')); ?>" alt="" width="80" height="80">
                <div class="clear"></div>
                <h5 style="font-size: 24px; color: #000; margin-top: 15px; font-weight:500;margin-bottom:15px">Alumni</h5>
                <div class="counter counter-small" style="font-family:'Lato', sans-serif; font-size: 48px; font-weight:700;color:#000;line-height: 0;padding-top: 15px;">
                    <span data-from="0" data-to="3" data-refresh-interval="1" data-speed="500"></span></div>

            </div>
            
        </div>

    </div>
</div><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/statistics.blade.php ENDPATH**/ ?>