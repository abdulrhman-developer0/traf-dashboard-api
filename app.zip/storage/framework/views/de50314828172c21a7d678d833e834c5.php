<footer id="footer" class="border-0 dark mt-4" 
style="background: linear-gradient(to bottom, rgba(0, 0, 0, 0.84), rgba(0, 0, 0, 0.73)), url('<?php echo e(asset('website-assets/images/footer-background.png')); ?>') no-repeat center center / cover">
    <div class="container">
        <!-- Footer Widgets
        ============================================= -->
        <div class="footer-widgets-wrap pb-5">

            <div class="row col-mb-50">
                <div class="col-md-4" style="padding-right: 100px;">
                    <div class="widget d-flex flex-column">

                        <img src="<?php echo e(asset('website-assets/images/footer-logo.png')); ?>" alt="Footer Logo" class="alignleft" style="margin-bottom: 20px">

                        <p style="margin-bottom: 10px;">
                            Knowledge University is private university that was established in 2009. The university is licensed from the Ministry of Higher Education & Scientific Research in the Kurdistan Region of Iraq.
                        </p>

                        <div class="widget m-0">
                            <a href="https://themeforest.net/user/SemiColonWeb/follow" target="_blank" class="social-icon border-0 h-bg-facebook mb-0 me-2">
                                <i class="fa-brands fa-facebook-f"></i>
                                <i class="fa-brands fa-facebook-f"></i>
                            </a>
                            <a href="https://themeforest.net/user/SemiColonWeb/follow" target="_blank" class="social-icon border-0 h-bg-instagram mb-0 me-2">
                                <i class="fa-brands fa-instagram"></i>
                                <i class="fa-brands fa-instagram"></i>
                            </a>
                            <a href="https://themeforest.net/user/SemiColonWeb/follow" target="_blank" class="social-icon border-0 h-bg-twitter mb-0 me-2">
                                <i class="fa-brands fa-twitter"></i>
                                <i class="fa-brands fa-twitter"></i>
                            </a>
                            <a href="https://themeforest.net/user/SemiColonWeb/follow" target="_blank" class="social-icon border-0 h-bg-linkedin mb-0 me-2">
                                <i class="fa-brands fa-linkedin-in"></i>
                                <i class="fa-brands fa-linkedin-in"></i>
                            </a>
                            <a href="https://themeforest.net/user/SemiColonWeb/follow" target="_blank" class="social-icon border-0 h-bg-youtube mb-0 me-2">
                                <i class="fa-brands fa-youtube"></i>
                                <i class="fa-brands fa-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">

                    <div class="widget">

                        <div class="row g-4">
                            <div class="col-lg-3 col-6 widget_links">
                                <h3>Dir & Units</h3>
                                <ul>
                                    <li><a href="#">Quality Assurance</a></li>
                                    <li><a href="#">Research Center</a></li>
                                    <li><a href="#">Vacancy</a></li>
                                    <li><a href="#">Alumni</a></li>
                                    <li><a href="#">Library</a></li>
                                    <li><a href="#">Conference Halls</a></li>
                                    <li><a href="#">Car Parking</a></li>
                                    <li><a href="#">Cafeteria</a></li>

                                </ul>
                            </div>

                            <div class="col-lg-3 col-6 widget_links">
                                <h3>Colleges</h3>

                                <ul>
                                    <li><a href="#">College of Pharmacy</a></li>
                                    <li><a href="#">College of Engineering</a></li>
                                    <li><a href="#">College of Science</a></li>
                                    <li><a href="#">College of Law</a></li>
                                    <li><a href="#">College of  Education</a></li>
                                    <li><a href="#">College of Administrative and financial Sciences</a></li>

                                </ul>
                            </div>

                            <div class="col-lg-3 col-6 widget_links">
                                <h3>Collaborations</h3>

                                <ul>
                                    <li><a href="#">Qalam University</a></li>
                                    <li><a href="#">Nukhba University</a></li>
                                    <li><a href="#">Kitab university</a></li>
                                </ul>
                            </div>

                            <div class="col-lg-3 col-6 widget_links">
                                <h3>Contact Info</h3>

                                <ul>
                                    <li><a href="#">Registry: <b>+9647503000600</b></a></li>
                                    <li><a href="#">Registry: <b>+9647503000700</b></a></li>
                                    <li><a href="#">Presidency: <b>+9647503000800</b></a></li>
                                    <li><a href="#">Knowledge University, Erbil 446015</a></li>
                                    <li><a href="#">info@knu.edu.iq</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>

                </div>

            </div>

        </div><!-- .footer-widgets-wrap end -->
    </div>

    <div id="copyrights" class="p-0">
        <div class="container" style="border-top: 1px solid #ffffff59;padding-top: 25px;padding-bottom: 25px;">

            <div class="text-center">
                &copy; Copyright 2023. All Rights Reserved by Knowledge University
            </div>

        </div>
    </div>
</footer><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/footer.blade.php ENDPATH**/ ?>