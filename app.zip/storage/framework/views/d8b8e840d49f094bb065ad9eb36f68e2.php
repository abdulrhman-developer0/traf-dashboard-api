<div class="section py-6" style="background: #E9F3FB;">
    <div class="container">
        <div class="heading-block border-bottom-0">
            <h3 class="text-transform-none ls-0 section-header">Latest Events</h3>
        </div>
    </div>
</div><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/latest-events.blade.php ENDPATH**/ ?>