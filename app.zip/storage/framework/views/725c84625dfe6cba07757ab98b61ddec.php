<div class="container py-4 researches">
    <div class="heading-block border-bottom-0 d-flex justify-content-between">
        <h3 class="text-transform-none ls-0 section-header">Latest Researches</h3>
        <button type="button" class="btn custombutton">View All Researches</button>
    </div>

    <div class="row">
        <div class="col-md-4">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/researches/1.png')); ?>" alt="" style="height: 325px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Research Title Here </a></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam, provident.</p>

                    </div>
                    
                </div>
            </article>
        </div>

        <div class="col-md-4">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/researches/3.png')); ?>" alt="" style="height: 325px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Research Title Here </a></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam, provident.</p>

                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/researches/2.png')); ?>" alt="" style="height: 325px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Research Title Here </a></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam, provident.</p>

                    </div>
                </div>
            </article>
        </div>
    </div>

</div>
<?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/latest-researches.blade.php ENDPATH**/ ?>