<div class="container py-4 news">
    <div class="heading-block border-bottom-0 d-flex justify-content-between">
        <h3 class="text-transform-none ls-0 section-header">News & Updates</h3>
        <button type="button" class="btn custombutton">View All News</button>
    </div>

    <div class="row">
        <div class="col-md-6">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 560px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Recognition from Prestigious British Institution ECCTIS </a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-6">
            <div class="row">
                <div class="col-md-6">
                    <article class="entry relative">
                        <div class="entry-image mb-3">
                            <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/2.png')); ?>" alt="" style="height: 250px;"></a>
                        </div>
                        <div class="overlaydata">
                            <div class="entry-title">
                                <h3><a href="#">Knowledge University Achieves Recognition from Prestigious... </a></h3>
                            </div>
                            <div class="entry-meta">
                                <ul>
                                    <li><a href="#"> 11 Mar 2021</a></li>
                                </ul>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="col-md-6">
                    <article class="entry relative">
                        <div class="entry-image mb-3">
                            <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/3.png')); ?>" alt="" style="height: 250px;"></a>
                        </div>
                        <div class="overlaydata">
                            <div class="entry-title">
                                <h3><a href="#">Knowledge University Achieves Recognition from Prestigious... </a></h3>
                            </div>
                            <div class="entry-meta">
                                <ul>
                                    <li><a href="#"> 11 Mar 2021</a></li>
                                </ul>
                            </div>
                        </div>
                    </article>
                </div>
            </div>

            <div class="col-md-12">
                <article class="entry relative">
                    <div class="entry-image mb-3">
                        <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/4.png')); ?>" alt="" style="height: 260px;"></a>
                    </div>
                    <div class="overlaydata">
                        <div class="entry-title">
                            <h3><a href="#">Knowledge University Achieves Recognition from Prestigious... </a></h3>
                        </div>
                        <div class="entry-meta">
                            <ul>
                                <li><a href="#"> 11 Mar 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </article>
            </div>

        </div>

        

        
    </div>

</div>
<?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/news.blade.php ENDPATH**/ ?>