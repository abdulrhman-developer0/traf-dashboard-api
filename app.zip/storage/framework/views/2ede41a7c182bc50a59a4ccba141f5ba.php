



<?php $__env->startSection('content'); ?>

<section class="page-title  scroll-detect dark" style="height: 400px;
background: linear-gradient(to bottom, rgba(0, 0, 0, 0.84), rgba(0, 0, 0, 0.73)), url('<?php echo e(asset('website-assets/images/artical-page-header.png')); ?>') no-repeat top center / cover">
    <div class="container">
        <div class="page-title-row mt-6">

            <div class="page-title-content">
                <h1 data-animate="fadeInUp" style="font-size: 40px;font-weight:700">Articles</h1>
                <span data-animate="fadeInUp" data-delay="300" style="font-size: 18px;font-weight:400">Home  -  Articles</span>
            </div>

           

        </div>
    </div>
</section>

<div class="container py-4 news my-6">

    <div class="row">
        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        <div class="col-md-4 mb-3">
            <article class="entry ">
                <div class="entry-image mb-3 relative">
                    <a href="#"><img src="<?php echo e(asset('website-assets/images/blog/1.png')); ?>" alt="" style="height: 342px;"></a>
                </div>
                <div class="overlaydata">
                    <div class="entry-title">
                        <h3><a href="#">Knowledge University Achieves Prestigious Ranking in (InCite...</a></h3>
                    </div>
                    <div class="entry-meta">
                        <ul>
                            <li><a href="#"> 11 Mar 2021</a></li>
                        </ul>
                    </div>
                </div>
            </article>
        </div>

        

        
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/articals.blade.php ENDPATH**/ ?>