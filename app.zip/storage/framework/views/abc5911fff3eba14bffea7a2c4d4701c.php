<!DOCTYPE html>
<html dir="<?php echo e(__('website.dir')); ?>" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8">
        <meta http-equiv="x-ua-compatible" content="IE=edge">
        <meta name="author" content="">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Font Imports -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Noto+Kufi+Arabic:wght@100..900&family=Noto+Naskh+Arabic:wght@400..700&display=swap" rel="stylesheet">

    
        <!-- Core Style -->
        <link rel="stylesheet" href="<?php echo e(asset('website-assets/css/style.css')); ?>">


        <!-- Font Icons -->
        <link rel="stylesheet" href="<?php echo e(asset('website-assets/css/font-icons.css')); ?>">

        <!-- Plugins/Components CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('website-assets/css/swiper.css')); ?>">

        <!-- Custom CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('website-assets/css/custom.css')); ?>">

        <?php if(app()->getLocale() == 'ar' || app()->getLocale() == 'ku'): ?>
            <link rel="stylesheet" href="<?php echo e(asset('website-assets/css/style-rlt.css')); ?>">
        <?php endif; ?>


        <!-- Document Title
        ============================================= -->
        <title>Knowledge University</title>

    </head>

    <body class="stretched">

        <div id="wrapper">
            <?php echo $__env->make('website.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <?php echo $__env->yieldContent('content'); ?>


            <?php echo $__env->make('website.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </div>


        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="uil uil-angle-up"></div>

        <!-- JavaScripts
        ============================================= -->
        <script src="<?php echo e(asset('website-assets/js/plugins.min.js')); ?>"></script>
        <script src="<?php echo e(asset('website-assets/js/functions.bundle.js')); ?>"></script>

    </body>
</html><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/layouts/main.blade.php ENDPATH**/ ?>