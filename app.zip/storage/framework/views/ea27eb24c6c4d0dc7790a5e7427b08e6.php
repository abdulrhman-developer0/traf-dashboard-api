<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Element</th>
            <th>Points</th>
            <th>Score</th>
            <th>Calculated Points</th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="2"><?php echo e($group->title); ?></td>
            </tr>
           
            <?php $__currentLoopData = $group['elements']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($element->id); ?></td>
                    <td bgcolor="#92D050"><?php echo e($element->title); ?></td>
                    <td bgcolor="#FFC000" align="center"><?php echo e($element->points); ?></td>
                    <td bgcolor="#DD7E6B" align="center"><?php echo e($element->score); ?></td>
                    <td align="center"><?php echo e($element->calculated_points); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/exports/qa-report.blade.php ENDPATH**/ ?>