



<?php $__env->startSection('content'); ?>

<section class="page-title  scroll-detect dark" style="height: 400px;
background: linear-gradient(rgba(0, 0, 0, 0.69), rgba(0, 0, 0, 0.73)),  url('<?php echo e(asset('website-assets/images/contact-header.png')); ?>') no-repeat top center / cover">
    <div class="container">
        <div class="page-title-row mt-6">

            <div class="page-title-content">
                <h1 data-animate="fadeInUp" style="font-size: 40px;font-weight:700">Contact Us</h1>
                <span data-animate="fadeInUp" data-delay="300" style="font-size: 18px;font-weight:400">Home  -  Contact Us</span>
            </div>

           

        </div>
    </div>
</section>


<div class="container py-4 mt-4">
    <div class="heading-block border-bottom-0 d-flex justify-content-between">
        <h3 class="text-transform-none ls-0 section-header">General Contact Information</h3>
    </div>

    <div class="row">
        <div class="col-md-4 d-flex">
            <div class="contactPageIcon">
                <i class="bi bi-geo-alt-fill"></i>
            </div>
            <div class="contactPagedata">
                <h4>Address</h4>
                <p>4rd Avenue,Upper East Side San Franciso</p>
            </div>
        </div>
        <div class="col-md-4 d-flex">
            <div class="contactPageIcon">
                <i class="bi bi-telephone-fill"></i>
            </div>
            <div class="contactPagedata">
                <h4>Phone</h4>
                <p>Mobile: (+88) - 1990 - 6886 <br> Hotline: 1800 - 1102 <br> Mail: contact@edumall.com</p>
            </div>
        </div>
        <div class="col-md-4 d-flex">
            <div class="contactPageIcon">
                <i class="bi bi-envelope-fill"></i>
            </div>
            <div class="contactPagedata">
                <h4>Hour of operation</h4>
                <p>Monday - Friday: 09:00 - 20:00 <br> Sunday & Saturday: 10:30 - 22:00</p>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/contact.blade.php ENDPATH**/ ?>