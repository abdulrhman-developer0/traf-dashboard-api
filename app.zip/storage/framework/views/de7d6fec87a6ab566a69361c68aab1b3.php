<div class="section py-6" style="background: #E9F3FB;margin-bottom: 10px;">
    <div class="container">
        <div class="heading-block border-bottom-0">
            <h3 class="text-transform-none ls-0 section-header">Student’s Reference</h3>
        </div>
    </div>
    <div class="container">

        <div class="row col-mb-50 justify-content-center">
            <div class="col-xl-3 col-md-6">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #000000a8), url(<?php echo e(asset('website-assets/images/students/1.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom:0;left:0;right:0">
                            <h3 class="card-title mb-0 text-white" style="font-size: 20px;font-weight:700">Future Students</h3>
                            <a href="#"><i class="fa-solid fa-chevron-up text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #000000a8), url(<?php echo e(asset('website-assets/images/students/2.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom:0;left:0;right:0">
                            <h3 class="card-title mb-0 text-white" style="font-size: 20px;font-weight:700">Current Students</h3>
                            <a href="#"><i class="fa-solid fa-chevron-up text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #000000a8), url(<?php echo e(asset('website-assets/images/students/3.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom:0;left:0;right:0">
                            <h3 class="card-title mb-0 text-white" style="font-size: 20px;font-weight:700">Alumni Association</h3>
                            <a href="#"><i class="fa-solid fa-chevron-up text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #000000a8), url(<?php echo e(asset('website-assets/images/students/4.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom:0;left:0;right:0">
                            <h3 class="card-title mb-0 text-white" style="font-size: 20px;font-weight:700">Continuing Education</h3>
                            <a href="#"><i class="fa-solid fa-chevron-up text-white"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/student-reference.blade.php ENDPATH**/ ?>