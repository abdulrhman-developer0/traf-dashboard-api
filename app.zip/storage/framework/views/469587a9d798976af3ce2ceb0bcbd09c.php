<section id="slider" class="slider-element min-vh-60 min-vh-md-100 include-header">
    <div class="slider-inner" style="background: #303090 url(<?php echo e(asset('website-assets/images/hero.png')); ?>) center center no-repeat; background-size: 98% 95%;">

        <div class="titlediv">
            <h1>The Knowledge University</h1>
        </div>
        
    </div>
</section><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/hero.blade.php ENDPATH**/ ?>