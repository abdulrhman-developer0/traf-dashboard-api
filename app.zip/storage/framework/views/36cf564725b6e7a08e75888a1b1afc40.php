<div class="container py-6 mb-6">
    <div class="heading-block border-bottom-0 d-flex justify-content-between">
        <h3 class="text-transform-none ls-0 section-header">Academic Programs</h3>
        <button type="button" class="btn custombutton">View All Programs</button>
    </div>
    <div class="container">

        <div class="row col-mb-50 justify-content-center">
            <div class="col-xl-4 col-md-6 p-0">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #303090ba), url(<?php echo e(asset('website-assets/images/academic/1.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom: 6px;left:0;right:0">
                            <h3 class="card-title mb-0 text-white px-5" style="font-size: 24px;font-weight:600">College Of Dentistry</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 p-0">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #303090ba), url(<?php echo e(asset('website-assets/images/academic/2.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom: 6px;left:0;right:0">
                            <h3 class="card-title mb-0 text-white px-5" style="font-size: 24px;font-weight:600">College Of Pharmacy</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 p-0">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #303090ba), url(<?php echo e(asset('website-assets/images/academic/3.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom: 6px;left:0;right:0">
                            <h3 class="card-title mb-0 text-white px-5" style="font-size: 24px;font-weight:600">Department Of Business Administration</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 p-0">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #303090ba), url(<?php echo e(asset('website-assets/images/academic/4.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom: 6px;left:0;right:0">
                            <h3 class="card-title mb-0 text-white px-5" style="font-size: 24px;font-weight:600">Department Of Information Technology</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 p-0">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #303090ba), url(<?php echo e(asset('website-assets/images/academic/5.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom: 6px;left:0;right:0">
                            <h3 class="card-title mb-0 text-white px-5" style="font-size: 24px;font-weight:600">Department Of Engineering</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-md-6 p-0">
                <div class="card border-0 p-3 dark" style="height:350px;border-radius: 0; background: linear-gradient(180deg, rgba(0,0,0,0), #303090ba), url(<?php echo e(asset('website-assets/images/academic/6.png')); ?>) no-repeat top center / cover;">
                    <div class="card-body text-center" style="position: relative">
                        <div style="position: absolute; bottom: 6px;left:0;right:0">
                            <h3 class="card-title mb-0 text-white px-5" style="font-size: 24px;font-weight:600">Department Of Social Sciences & Law</h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH D:\------- Work\------------------ SanaMedia\projects\ims-dashboard\resources\views/website/partials/academic-programs.blade.php ENDPATH**/ ?>