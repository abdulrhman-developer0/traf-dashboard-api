<?php

return [

    'dir' => 'ltr',

];
