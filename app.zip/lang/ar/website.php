<?php

return [

    'dir' => 'rtl',

];
